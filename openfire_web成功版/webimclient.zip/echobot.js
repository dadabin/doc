var BOSH_SERVICE = '/http-bind/';
var connection = null;
var toId=null;
var fromId=null;

Strophe.log = function (level, msg) {
    //$('#log').append('<div></div>').append(document.createTextNode(msg));
};

function rawInput(data)
{
    log('RECV: ' + data);
}

function rawOutput(data)
{
    log('SENT: ' + data);
}


function log(msg)
{
    //$('#log').append('<div></div>').append(document.createTextNode(msg));
}

function onConnect(status)
{
    if (status == Strophe.Status.CONNECTING) {
	log('Strophe is connecting.');
    } else if (status == Strophe.Status.CONNFAIL) {
	log('Strophe failed to connect.');
	$('#connect').get(0).value = 'connect';
    } else if (status == Strophe.Status.DISCONNECTING) {
	log('Strophe is disconnecting.');
    } else if (status == Strophe.Status.DISCONNECTED) {
	log('Strophe is disconnected.');
	$('#connect').get(0).value = 'connect';
    } else if (status == Strophe.Status.CONNECTED) {
	log('Strophe is connected.');

	connection.addHandler(onMessage, null, 'message', null, null,  null);
	connection.send($pres().tree());
    }
}

function onMessage(msg) {
    to = msg.getAttribute('from');
    var from = msg.getAttribute('from');
    var type = msg.getAttribute('type');
    var elems = msg.getElementsByTagName('body');

    if (type == "chat" && elems.length > 0) {
	    var body = elems[0];
    	appendToHis(new Date().toLocaleTimeString() + '  ' + from + ' say: ' + Strophe.getText(body));
    }

    // we must return true to keep the handler alive.
    // returning false would remove it after it finishes.
    return true;
}

function appendToHis(msg){
    $('#his').append('<div>' + msg + '</div>');
    $('#his').attr("scrollTop", $('#his').attr("scrollHeight"));
}

$(document).ready(function () {
    connection = new Strophe.Connection(BOSH_SERVICE);

    connection.rawInput = rawInput;
    connection.rawOutput = rawOutput;

    //Strophe.log = function (level, msg) { log('LOG: ' + msg); };


    $('#connect').bind('click', function () {
	var button = $('#connect').get(0);
	if (button.value == 'connect') {
	    button.value = 'disconnect';

        fromId = $('#jid').val();
        toId = $('#tojid').val();

        log(fromId);
        log(toId);

	    connection.connect($('#jid').get(0).value,
			       $('#pass').get(0).value,
			       onConnect);
	} else {
	    button.value = 'connect';
	    connection.disconnect();
	}
    });

    $('#send').bind('click', function () {
        msg=$('#msg').val();

        toId = $('#tojid').val();
	    var reply = $msg({to: toId, from: fromId , type: 'chat'}).cnode(Strophe.xmlElement('body', '' ,msg));
	    connection.send(reply.tree());

	    appendToHis(new Date().toLocaleTimeString() + "  Me:  "  + msg);
	    $('#msg').val('');
    });


    $('#msg').keypress(function(e){
        if(e.which==13){
            $('#send').click();
        }
    });

});
